import boto3
import hashlib
import json
import psycopg2
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# AWS SQS and Postgres Configuration
QUEUE_URL = 'http://localhost:4566/000000000000/login-queue'
DATABASE_CONFIG = {
    'dbname': 'postgres',
    'user': 'postgres',
    'password': 'postgres',
    'host': 'localhost',
    'port': 5432
}

# Connect to the Postgres database
def connect_to_db():
    try:
        conn = psycopg2.connect(**DATABASE_CONFIG)
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

# Mask PII data
def mask_pii(value):
    return hashlib.sha256(value.encode()).hexdigest()

# Process and insert data into Postgres
def process_and_insert_data(messages):
    conn = connect_to_db()
    if conn is None:
        return
    
    cursor = conn.cursor()

    for message in messages:
        data = json.loads(message['Body'])

        user_id = data.get('user_id')
        device_type = data.get('device_type')
        masked_ip = mask_pii(data.get('ip'))
        masked_device_id = mask_pii(data.get('device_id'))
        locale = data.get('locale')
        app_version = data.get('app_version')
        create_date = data.get('create_date')

        insert_query = """
        INSERT INTO user_logins (user_id, device_type, masked_ip, masked_device_id, locale, app_version, create_date)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (user_id, device_type, masked_ip, masked_device_id, locale, app_version, create_date))

    conn.commit()
    cursor.close()
    conn.close()

# Read messages from SQS
def read_messages_from_sqs():
    sqs = boto3.client('sqs', region_name='us-east-1', endpoint_url='http://localhost:4566')

    try:
        response = sqs.receive_message(QueueUrl=QUEUE_URL, MaxNumberOfMessages=10)
        return response.get('Messages', [])
    except (NoCredentialsError, PartialCredentialsError) as e:
        print(f"Credentials error: {e}")
        return []

if __name__ == "__main__":
    messages = read_messages_from_sqs()
    if messages:
        process_and_insert_data(messages)
    else:
        print("No messages found in the queue.")
